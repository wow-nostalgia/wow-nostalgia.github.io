local addonName = ...
local frame = CreateFrame("Frame")

local waitingForRoster = false
local SERVER_NAME = "FreedomUA"

local function InitDB()
    if not GuildRosterExportMiniDB then
        GuildRosterExportMiniDB = {}
    end

    if not GuildRosterExportMiniDB.players then
        GuildRosterExportMiniDB.players = {}
    end
end

local function BuildPlayersList()
    SetGuildRosterShowOffline(true)

    local totalMembers = GetNumGuildMembers()
    local players = {}

    for i = 1, totalMembers do
        local fullName = GetGuildRosterInfo(i)

        if fullName and fullName ~= "" then
            local name = string.match(fullName, "^[^-]+") or fullName

            table.insert(players, {
                name = name,
                server = SERVER_NAME
            })
        end
    end

    table.sort(players, function(a, b)
        return string.lower(a.name) < string.lower(b.name)
    end)

    return players
end

local function SaveRoster()
    InitDB()

    GuildRosterExportMiniDB.exportedAt = date("!%Y-%m-%dT%H:%M:%SZ")
    GuildRosterExportMiniDB.guildName = GetGuildInfo("player")
    GuildRosterExportMiniDB.realmName = GetRealmName()
    GuildRosterExportMiniDB.players = BuildPlayersList()

    DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00GuildRosterExportMini: saved players list (name + server).|r")
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00Type /reload or logout, then open WTF\\Account\\<ACCOUNT>\\SavedVariables\\GuildRosterExportMini.lua|r")
end

local function StartExport()
    if not IsInGuild() then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff0000GuildRosterExportMini: you are not in a guild.|r")
        return
    end

    waitingForRoster = true
    GuildRoster()
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00GuildRosterExportMini: requesting guild roster...|r")
end

frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("GUILD_ROSTER_UPDATE")

frame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == addonName then
        InitDB()

        SLASH_GUILDROSTEREXPORTMINI1 = "/groster"
        SlashCmdList["GUILDROSTEREXPORTMINI"] = function(msg)
            StartExport()
        end

        DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00GuildRosterExportMini loaded. Type /groster|r")
    elseif event == "GUILD_ROSTER_UPDATE" and waitingForRoster then
        waitingForRoster = false
        SaveRoster()
    end
end)