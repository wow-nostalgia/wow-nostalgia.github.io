/groster


відкривай файл:
World of Warcraft\WTF\Account\<ТВІЙ_АКАУНТ>\SavedVariables\GuildRosterExportMini.lua